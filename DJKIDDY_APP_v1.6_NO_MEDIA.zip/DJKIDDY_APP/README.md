# DJKIDDY APP v1.6 — APK Build Ready

This project is prepared for a GitHub Actions cloud build.

## Important: GitHub 25 MB browser upload limit
One bundled MP4 is larger than GitHub's 25 MB web upload limit. It has been split into two smaller files:
- `app/src/main/res/raw/djkiddy_media_2.mp4.part00`
- `app/src/main/res/raw/djkiddy_media_2.mp4.part01`

The GitHub Actions workflow automatically joins those parts back into `djkiddy_media_2.mp4` before compiling the APK.

## Build
Open GitHub → Actions → Build DJKIDDY APK → Run workflow.
After a successful run, download the artifact `DJKIDDY-APP-v1.6-debug-apk` and install the APK on Android.

Includes local player, bundled media, DJKIDDY logo, YouTube links, and AdMob test integration.
