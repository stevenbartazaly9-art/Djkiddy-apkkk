plugins {
    id("com.android.application")
}

android {
    namespace = "com.djkiddy.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.djkiddy.app"
        minSdk = 23
        targetSdk = 37
        versionCode = 2
        versionName = "1.6"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.4.0")
}
