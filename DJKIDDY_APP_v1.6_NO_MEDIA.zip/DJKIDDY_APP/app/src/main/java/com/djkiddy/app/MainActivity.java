package com.djkiddy.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;
import android.media.MediaPlayer;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends Activity {
    LinearLayout root;
    int blue=Color.rgb(0,168,255), bg=Color.rgb(5,7,10), card=Color.rgb(13,18,25);
    MediaPlayer player;
    AdView bannerAd;

    final String[] names={"DG Mido Mixing","DJKIDDY Video Mix","DJKIDDY Session"};
    final String[] urls={
        "https://youtu.be/EwHCgtzU8KA?si=ZL6rciJpRFBf6p73",
        "https://youtu.be/uUSIZqfOLn0?si=uGA76_QKl84GNddg",
        "https://youtu.be/Wsbmx9iWSDQ?si=yvsTLWUMXNUdthb6"
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        new Thread(() -> MobileAds.initialize(this, status -> {})).start();
        showHome();
    }
    @Override protected void onDestroy(){
        if(player!=null){player.release();player=null;}
        if(bannerAd!=null){bannerAd.destroy();bannerAd=null;}
        super.onDestroy();
    }

    TextView tv(String s,float z,int c,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);
        t.setGravity(Gravity.CENTER);t.setPadding(10,7,10,7);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    Button btn(String s){
        Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);
        b.setAllCaps(false);b.setBackgroundColor(Color.rgb(12,38,60));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58);p.setMargins(16,6,16,6);
        b.setLayoutParams(p);return b;
    }
    void root(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(bg);root.setPadding(0,10,0,10);
        setContentView(root);
        addBannerAd();
    }
    void logo(int h){
        ImageView i=new ImageView(this);i.setImageResource(R.drawable.djkiddy_logo);
        i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(i,new LinearLayout.LayoutParams(-1,h));
    }

    void showHome(){
        stop();
        root();logo(200);root.addView(tv("DJKIDDY",30,Color.WHITE,true));
        root.addView(tv("OFFICIAL APP • MUSIC • MIXES • VIDEOS",13,blue,true));
        Button m=btn("🎵  MUSIC PLAYER"),y=btn("▶  YOUTUBE"),t=btn("♪  TIKTOK");
        Button a=btn("ℹ  ABOUT DJKIDDY"),c=btn("☎  CONTACT");
        root.addView(m);root.addView(y);root.addView(t);root.addView(a);root.addView(c);
        m.setOnClickListener(v->showMusic());y.setOnClickListener(v->open(urls[0]));
        t.setOnClickListener(v->open("https://www.tiktok.com/@official_djkiddy"));
        a.setOnClickListener(v->showAbout());c.setOnClickListener(v->showContact());
    }

    void showMusic(){
        root();root.addView(tv("🎧 DJKIDDY PLAYER",25,Color.WHITE,true));
        root.addView(tv("Your uploaded media + YouTube mixes",13,Color.LTGRAY,false));

        for(int i=0;i<3;i++){
            final int n=i; LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(14,8,14,8);r.setBackgroundColor(card);
            ImageView art=new ImageView(this);art.setImageResource(R.drawable.djkiddy_logo);
            r.addView(art,new LinearLayout.LayoutParams(82,82));
            TextView info=tv(names[i]+"\nLOCAL PLAYER",15,Color.WHITE,true);info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            r.addView(info,new LinearLayout.LayoutParams(0,82,1));
            Button p=new Button(this);p.setText("▶");p.setTextColor(Color.WHITE);p.setTextSize(20);p.setBackgroundColor(Color.TRANSPARENT);
            r.addView(p,new LinearLayout.LayoutParams(60,82));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,98);rp.setMargins(10,5,10,5);root.addView(r,rp);
            r.setOnClickListener(v->showPlayer(n));p.setOnClickListener(v->showPlayer(n));
        }

        TextView yt=tv("YouTube mixes",18,blue,true);root.addView(yt);
        for(int i=0;i<3;i++){
            final int n=i;Button b=btn("▶ "+names[i]+" • YouTube");
            root.addView(b);b.setOnClickListener(v->open(urls[n]));
        }
        Button back=btn("← Back");root.addView(back);back.setOnClickListener(v->showHome());
    }

    void showPlayer(int index){
        root();root.addView(tv("NOW PLAYING",12,blue,true));root.addView(tv(names[index],25,Color.WHITE,true));
        logo(260);

        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setGravity(Gravity.CENTER);
        p.setPadding(12,12,12,12);p.setBackgroundColor(card);
        TextView state=tv("READY",13,Color.LTGRAY,true);p.addView(state);

        SeekBar seek=new SeekBar(this);p.addView(seek,new LinearLayout.LayoutParams(-1,45));
        TextView time=tv("00:00 / 00:00",12,Color.GRAY,false);p.addView(time);

        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);
        Button prev=ctrl("⏮"), play=ctrl("▶"), next=ctrl("⏭");controls.addView(prev);controls.addView(play);controls.addView(next);p.addView(controls);

        Button yt=btn("▶  OPEN ON YOUTUBE"),back=btn("← BACK TO MUSIC");
        p.addView(yt);p.addView(back);root.addView(p,new LinearLayout.LayoutParams(-1,-2));

        int res=0;
        if(index==0) res=R.raw.djkiddy_media_1;
        if(index==1) res=R.raw.djkiddy_media_2;
        if(index==2) res=R.raw.djkiddy_media_3;

        final int resource=res;
        if(resource!=0){
            try{
                player=MediaPlayer.create(this,resource);
                if(player!=null){
                    seek.setMax(player.getDuration());
                    time.setText(format(0)+" / "+format(player.getDuration()));
                    player.setOnCompletionListener(mp->{play.setText("▶");state.setText("FINISHED");});
                    play.setOnClickListener(v->{
                        if(player.isPlaying()){player.pause();play.setText("▶");state.setText("PAUSED");}
                        else{player.start();play.setText("Ⅱ");state.setText("PLAYING");}
                    });
                    seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                        public void onProgressChanged(SeekBar s,int x,boolean f){time.setText(format(x)+" / "+format(player.getDuration()));}
                        public void onStartTrackingTouch(SeekBar s){}
                        public void onStopTrackingTouch(SeekBar s){player.seekTo(s.getProgress());}
                    });
                }
            }catch(Exception e){state.setText("MEDIA ERROR");}
        }else state.setText("MEDIA NOT FOUND");

        yt.setOnClickListener(v->open(urls[index]));back.setOnClickListener(v->{stop();showMusic();});
        prev.setOnClickListener(v->{stop();showPlayer((index+2)%3);});
        next.setOnClickListener(v->{stop();showPlayer((index+1)%3);});
    }

    String format(int ms){int s=ms/1000;return String.format(java.util.Locale.US,"%02d:%02d",s/60,s%60);}
    Button ctrl(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(23);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    void stop(){if(player!=null){player.stop();player.release();player=null;}}
    void open(String u){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception ignored){}}

    void addBannerAd(){
        try {
            bannerAd = new AdView(this);
            bannerAd.setAdSize(AdSize.BANNER);
            // Google test banner ID. Replace with your own AdMob ad unit ID before publishing.
            bannerAd.setAdUnitId("ca-app-pub-3940256099942544/9214589741");
            LinearLayout.LayoutParams adParams = new LinearLayout.LayoutParams(-1, -2);
            adParams.setMargins(0, 8, 0, 0);
            root.addView(bannerAd, adParams);
            bannerAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception ignored) {}
    }

    void showAbout(){root();logo(210);root.addView(tv("About DJKIDDY",24,Color.WHITE,true));root.addView(tv("Official DJKIDDY music and content app.",16,Color.LTGRAY,false));Button b=btn("← Back");root.addView(b);b.setOnClickListener(v->showHome());}
    void showContact(){root();root.addView(tv("CONTACT DJKIDDY",24,Color.WHITE,true));root.addView(tv("YouTube: @iam_djkiddy",16,Color.WHITE,true));root.addView(tv("TikTok: @official_djkiddy",16,Color.WHITE,true));Button b=btn("← Back");root.addView(b);b.setOnClickListener(v->showHome());}
}
